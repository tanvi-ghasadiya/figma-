package com.example.tanvi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
