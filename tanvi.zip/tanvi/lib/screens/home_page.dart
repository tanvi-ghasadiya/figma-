import 'dart:html';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class home_page extends StatefulWidget {
  const home_page({Key? key}) : super(key: key);

  @override
  State<home_page> createState() => _home_pageState();
}

class _home_pageState extends State<home_page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 30,),
            Row(
              children: [
                SizedBox(width: 150,),
                Container(
                  height: 80,
                  width: 200,
                  decoration:BoxDecoration(
                    borderRadius:BorderRadius.circular(10),
                    color: Colors.grey
                  ),
                ),
                SizedBox(width: 300,),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment:CrossAxisAlignment.center,
                    children: [
                      Text("Home  "),
                      SizedBox(width: 20,),
                      Text("About us  "),
                      SizedBox(width: 20,),
                      Text("About us  "),
                      SizedBox(width: 20,),
                      Text("Contact us  "),
                    ],
                  ),

                ),
                SizedBox(width:300,),
                Container(
                  height: 60,
                  width: 160,
                  decoration:BoxDecoration(
                      borderRadius:BorderRadius.circular(10),
                      color: Colors.grey
                  ),
                  child: Text("\ncall to action",textAlign:TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
                ),
              ],
            ),
            Row(
              children: [
                Column(
                  children: [
                    Center(
                      child: Container(
                        width:500,
                        child: Row(
                          children: [
                            SizedBox(width: 100,height: 300,),
                            Text("     The future of web\ndesign, today",textAlign:TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 40),),
                          ],
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Text("                The future of web design, today",textAlign:TextAlign.center,style: TextStyle(fontSize: 20),),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
